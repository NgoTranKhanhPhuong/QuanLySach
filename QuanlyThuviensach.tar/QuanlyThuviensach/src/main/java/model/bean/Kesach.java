package model.bean;

public class Kesach {
	private int idKesach;
	private String nameKesach;
	public Kesach() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getIdKesach() {
		return idKesach;
	}
	public void setIdKesach(int idKesach) {
		this.idKesach = idKesach;
	}
	public String getNameKesach() {
		return nameKesach;
	}
	public void setNameKesach(String nameKesach) {
		this.nameKesach = nameKesach;
	}
	public Kesach(int idKesach, String nameKesach) {
		super();
		this.idKesach = idKesach;
		this.nameKesach = nameKesach;
	}
	
}
